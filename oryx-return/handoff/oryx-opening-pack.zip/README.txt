Oryx video - opening shot (0.0s to 6.6s), 1080x1920, 30 fps

Timeline of the opening:
  0.0 - 2.5s  herd of oryx running across the savanna, hoof sounds, no voice yet
  2.6s        voice: "هذا الحيوان..."  (this animal...)
  4.1s        voice: "اختفى من البرية" (disappeared from the wild) -> herd starts vanishing one by one
  4.1 - 6.0s  oryx vanish one by one, hoof sound thins out with them
  6.0 - 6.6s  empty land, then cut to the next scene

Files:
  01..07_tX.Xs.png        frames in time order, time printed on the image
  clean/                  the same frames without the time label (for editing)
  00_background_empty.jpg the savanna background with no animals
  00_oryx_outline.png     the oryx silhouette used for the herd

Text area: keep titles between y=168 and y=1330. Animals live on the ground from about y=1000 down.
